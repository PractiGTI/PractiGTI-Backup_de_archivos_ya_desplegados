const express = require('express');
const bodyParser = require('body-parser');
const auth = require('./routes/authentication.js');
const factores = require('./routes/factor.js');
const practicas = require('./routes/practica.js');
const diagnosticos = require('./routes/diagnostico.js');
const universidades = require('./routes/universidad.js');
const users = require('./routes/profile.js');
const tratamientos = require('./routes/tratamiento.js');

const app=express();
const PORT =5000;

app.use(bodyParser.json());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "https://practigti.net.pe"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "POST, PUT, GET, PATCH, DELETE, OPTIONS")
    next();
  });

//app.use('/users',usersRoutes);

app.get('/',(req,res)=>{
    res.send("Hello from Homepage");
});

app.use('',auth);

app.use('/factores',factores);
app.use('/practicas',practicas);
app.use('/diagnosticos',diagnosticos);
app.use('/universidades',universidades);
app.use('/users',users);
app.use('/tratamientos',tratamientos);

app.listen(PORT,()=>{console.log(`Server Running on port: http://localhost:${PORT}`)});