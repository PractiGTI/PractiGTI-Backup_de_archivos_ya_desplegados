const { Router } = require("express");
const pool = require("../database/database.js");
const helpers = require("../lib/helpers.js");
const jwt = require("jsonwebtoken");
const config = require('../config.js');
const sgMail = require('@sendgrid/mail');
const { methods } = require("../controllers/authentication.controller.js");
const authenticationController = methods;

sgMail.setApiKey(config.SENDGRID_API_KEY);

const router = Router();


router.post('/signup', authenticationController.signUp)

router.post('/signin', authenticationController.signIn)

router.post("/forgot-password", authenticationController.forgotPassword)

router.put("/new-password", authenticationController.newPassword)

module.exports =  router;