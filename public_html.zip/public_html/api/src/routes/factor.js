const { Router } = require("express");
const { methods } = require('../controllers/factor.controller.js');
const pool = require("../database/database.js");
const factorController = methods;

const router = Router();

router.get("/", factorController.getFactores);

router.get("/:id", factorController.getFactorById);

router.get("/preguntas", factorController.getPreguntasByFactores);

router.get("/:factorId/users/:userId/practicas", factorController.getPracticasByFactorId);

module.exports =  router;