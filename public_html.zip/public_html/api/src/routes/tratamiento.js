const { Router } = require("express");
const { methods } = require('../controllers/tratamiento.controller.js');
const pool = require("../database/database.js");
const tratamientoController = methods;

const router = Router();

router.get("/factores/:factorId/practicas", tratamientoController.getPracticasByFactorId);

module.exports =  router;