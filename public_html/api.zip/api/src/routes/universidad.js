const { Router } = require("express");
const { methods } = require('../controllers/universidad.controller.js');
const universidadController = methods;

const router = Router();

router.get("/", universidadController.getUniversidades);
router.get("/:id", universidadController.getUniversidadById);

module.exports =  router;