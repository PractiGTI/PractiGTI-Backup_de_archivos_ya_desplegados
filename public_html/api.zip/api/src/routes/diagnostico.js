const { Router } = require("express");
const { methods } = require('../controllers/diagnostico.controller.js');
const pool = require("../database/database.js");
const diagnosticoController = methods;
const router = Router();

router.post("/", diagnosticoController.createDiagnostico);

module.exports =  router;